import tempfile
import unittest
from pathlib import Path

import numpy as np
from scipy.integrate import quad
from scipy.special import ndtr
import torch

from capacity import (ROOT, GroupMLP, generate, joint_probability,
                      torch_joint_probability)


class CapacityTests(unittest.TestCase):
    def test_dataset_regenerates_exactly(self):
        with tempfile.TemporaryDirectory() as path:
            directory = Path(path)
            generate(directory)
            for name in ("buildings.csv", "portfolios.csv", "group_truth.csv"):
                self.assertEqual((directory / name).read_bytes(),
                                 (ROOT / "data" / name).read_bytes())

    def test_pair_probability_and_gradient(self):
        a = np.array([-1.15, 0.92, 1.15])
        b = np.array([1.15, -1.15, -0.75])
        rho = np.array([-0.92, 0.60, 0.92])
        expected = np.array([quad(
            lambda x: np.exp(-x*x/2)/np.sqrt(2*np.pi) *
            ndtr((bb-rr*x)/np.sqrt(1-rr*rr)), -np.inf, aa
        )[0] for aa, bb, rr in zip(a, b, rho)])
        np.testing.assert_allclose(joint_probability(a, b, rho), expected, atol=1e-6)
        rho_tensor = torch.tensor(rho, requires_grad=True)
        actual = torch_joint_probability(torch.tensor(a), torch.tensor(b), rho_tensor)
        np.testing.assert_allclose(actual.detach().numpy(), expected, atol=1e-6)
        actual.sum().backward()
        self.assertTrue(torch.isfinite(rho_tensor.grad).all())

    def test_outcome_probabilities_preserve_marginals(self):
        a, b, rho = 0.6, -0.8, 0.70
        probs = np.array([[joint_probability(sa*a, sb*b, sa*sb*rho)
                           for sb in (1, -1)] for sa in (1, -1)])
        self.assertAlmostEqual(probs.sum(), 1)
        self.assertAlmostEqual(probs[0].sum(), ndtr(a))
        self.assertAlmostEqual(probs[:, 0].sum(), ndtr(b))

    def test_soft_loadings_define_valid_covariance(self):
        model = GroupMLP().double()
        x = torch.tensor([[0.9, -0.2], [0.3, 0.4], [-0.6, 0.3]], dtype=torch.float64)
        q, w = model(x)
        loadings = q * w.sqrt()
        residual = 1 - loadings.square().sum(dim=1)
        cov = loadings @ loadings.T + torch.diag(residual)
        torch.testing.assert_close(cov.diag(), torch.ones(len(x), dtype=x.dtype))
        self.assertTrue((torch.linalg.eigvalsh(cov) > 0).all())


if __name__ == "__main__":
    unittest.main()
